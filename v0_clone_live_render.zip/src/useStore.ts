
import { create } from 'zustand'

const STARTER = `import React from 'react';
export default function Products(){
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Ürünler</h1>
        <div className="flex gap-2 text-sm">
          <button className="px-3 py-1 rounded-card border">+</button>
          <button className="px-3 py-1 rounded-card border">⋮</button>
        </div>
      </div>
      <div className="flex gap-2">
        <input placeholder="Ürünleri filtrele" className="flex-1 p-2 border rounded-card" />
        <button className="px-3 py-2 rounded-card border">↕</button>
        <button className="px-3 py-2 rounded-card border">☰</button>
      </div>
      <div className="flex gap-2 text-sm border-b">
        <button className="py-2 border-b-2 border-black">Tümü</button>
        <button className="py-2 text-neutral-500">Etkin</button>
        <button className="py-2 text-neutral-500">Taslak</button>
        <button className="py-2 text-neutral-500">Arşivlenen</button>
      </div>
      <div className="grid gap-3">
        {[1,2,3,4,5].map(i => (
          <div key={i} className="flex items-center gap-3 bg-white p-3 rounded-card border">
            <div className="w-14 h-14 bg-neutral-200 rounded-md" />
            <div className="flex-1">
              <div className="font-medium">Sneaker Model {i}</div>
              <div className="text-xs text-neutral-500">{2+i} varyasyon</div>
            </div>
            <span className="text-xs px-2 py-1 rounded-full bg-emerald-100 text-emerald-700">Aktif</span>
          </div>
        ))}
      </div>
    </div>
  )
}`

type Store = {
  code: string
  setCode: (s:string)=>void
}

export const useBuilderStore = create<Store>((set)=> ({
  code: STARTER,
  setCode: (s)=> set({code: s})
}))
