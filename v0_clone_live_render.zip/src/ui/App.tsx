
import React, { useState } from "react";
import { useBuilderStore } from "../useStore";
import { PromptBar } from "./PromptBar";
import { Split } from "./Split";
import { LivePreview } from "./LivePreview";
import { MonacoPane } from "./MonacoPane";

export default function App() {
  const { code } = useBuilderStore();
  const [vertical, setVertical] = useState(true);
  return (
    <div className="h-screen flex flex-col">
      <header className="px-4 py-3 border-b bg-white flex items-center justify-between">
        <div className="font-semibold text-sneak.text">v0-like AI Builder</div>
        <div className="text-sm text-neutral-500">Live preview • Monaco + Sandpack</div>
      </header>
      <PromptBar />
      <Split vertical={vertical}>
        <MonacoPane />
        <LivePreview code={code} />
      </Split>
      <footer className="px-4 py-2 text-xs text-neutral-500 border-t bg-white">
        SneakGO • Shopify-klon üretici demo • React + Vite + Tailwind
      </footer>
    </div>
  );
}
