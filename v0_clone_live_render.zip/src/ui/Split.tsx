
import React from 'react'

export function Split({children, vertical}:{children:React.ReactNode[], vertical:boolean}){
  return (
    <div className="flex-1 flex min-h-0">
      <div className="w-1/2 min-w-[300px] border-r overflow-auto">{children[0]}</div>
      <div className="w-1/2 min-w-[300px] overflow-auto">{children[1]}</div>
    </div>
  )
}
