
import React from 'react'
import { SandpackProvider, SandpackLayout, SandpackPreview, SandpackFileExplorer } from '@codesandbox/sandpack-react'

// We mount the generated code into a Vite-ready template inside Sandpack runtime.
export function LivePreview({code}:{code:string}){
  const files = {
    "/index.tsx": `import React from 'react'; import { createRoot } from 'react-dom/client'; import './index.css'; import Products from './generated/Products'; 
      function App(){ return <div className='w-[390px] mx-auto p-3'><Products/></div> } 
      createRoot(document.getElementById('root')).render(<App/>)`,
    "/index.css": `@tailwind base;@tailwind components;@tailwind utilities; body{font-family: ui-sans-serif, system-ui; background:#fafafa}`,
    "/generated/Products.tsx": code || "export default () => <div>AI kodu burada görünecek.</div>",
    "/tailwind.config.js": `export default { content:['./**/*.{ts,tsx,html}'], theme:{ extend:{ colors:{ primary:'#FF007F' }, borderRadius:{ card:'16px'} } }, plugins:[] }`,
    "/postcss.config.js": `export default { plugins: { tailwindcss: {}, autoprefixer: {} } }`,
    "/index.html": `<!doctype html><html><body><div id='root'></div><script type='module' src='/index.tsx'></script></body></html>`,
    "/package.json": JSON.stringify({
      name: "sandpack-sneakgo",
      main: "/index.tsx",
      dependencies: {
        react: "18.2.0",
        "react-dom": "18.2.0"
      }
    }, null, 2)
  }

  return (
    <SandpackProvider template="react" files={files} customSetup={{}}>
      <SandpackLayout>
        <SandpackFileExplorer style={{minWidth:220}} />
        <SandpackPreview showOpenInCodeSandbox={false} />
      </SandpackLayout>
    </SandpackProvider>
  )
}
