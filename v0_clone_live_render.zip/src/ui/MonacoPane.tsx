
import React, { useEffect, useRef } from 'react'
import * as monaco from 'monaco-editor'
import { useBuilderStore } from '../useStore'

export function MonacoPane(){
  const ref = useRef<HTMLDivElement>(null)
  const { code, setCode } = useBuilderStore()

  useEffect(()=>{
    if(!ref.current) return
    const editor = monaco.editor.create(ref.current, {
      value: code,
      language: 'typescript',
      automaticLayout: true,
      minimap: { enabled: false },
      theme: 'vs',
      fontSize: 13
    })
    const d = editor.onDidChangeModelContent(()=> setCode(editor.getValue()))
    return ()=> { d.dispose(); editor.dispose() }
  },[])

  return <div className="h-full" ref={ref} />
}
