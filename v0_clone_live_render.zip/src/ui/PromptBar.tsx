
import React, { useState } from 'react'
import { useBuilderStore } from '../useStore'
import { buildWithAI } from '../utils/ai'

const DEFAULT_PROMPT = `
Shopify Mobile Admin'in Ürünler ekranını (Üst bar, sekmeler: Tümü/Etkin/Taslak/Arşivlenen, arama çubuğu, ürün listesi satırı: görsel 1:1, ad, 'N varyasyon', sağda durum rozeti) birebir üret.
React + Tailwind ile tek dosyalık bir komponent döndür: src/generated/Products.tsx
Mobil-first genişlik 390px grid. Piksel toleransı ≤2px.
`

export function PromptBar() {
  const [prompt, setPrompt] = useState(DEFAULT_PROMPT.trim())
  const [loading, setLoading] = useState(false)
  const { setCode } = useBuilderStore()

  async function onGenerate() {
    setLoading(true)
    try {
      const result = await buildWithAI(prompt)
      setCode(result.code)
    } catch (e:any) {
      alert('AI hata: ' + e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-3 border-b bg-neutral-50">
      <div className="flex gap-2">
        <textarea
          className="flex-1 p-3 border rounded-card text-sm"
          rows={3}
          value={prompt}
          onChange={e=>setPrompt(e.target.value)}
        />
        <button
          onClick={onGenerate}
          disabled={loading}
          className="px-4 py-2 rounded-card bg-sneak.pink text-white text-sm hover:opacity-90 disabled:opacity-50"
          title="AI ile oluştur"
        >
          {loading ? 'Oluşturuluyor…' : 'AI ile oluştur'}
        </button>
      </div>
    </div>
  )
}
