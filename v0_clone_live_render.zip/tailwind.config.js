
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        sneak: {
          pink: "#FF007F",
          text: "#111111"
        }
      },
      borderRadius: {
        card: "16px"
      }
    },
  },
  plugins: [],
}
